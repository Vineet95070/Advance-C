enum:
	enum is a user defind data type that is use to store data with there 
	indexes:
		-	enum keyword is use to define enum data type.
		
	Syntax:
		enum enum_name{
			
			var1,
			var2,
			var3
		};
		

typedef:
	The typedef keyword in C (and C++) allows you to create an alias or 
	alternate name for existing data types.
	
	Syntax:
		typedef previous_name new_name;		
		
		
		
