#include <stdio.h>

int main(){
	
	int arr[5] = {23, 54, 78, 23, 87};
	
	int i=0;
	while(i != 5){
		
		printf("%d ", arr[i]);
		
		i++;
	}
	
	return 0;
}
