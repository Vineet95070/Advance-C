#include <stdio.h>

int main(){
	
	int *ptr = (int *)malloc( 6 );
	
	int *ptr = (int *)malloc(n * sizeof(int));
	
	char *ptr = (char *)malloc( 6 );
	
	return 0;
}
