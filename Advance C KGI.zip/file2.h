
float cgpa = 8.5;

void details(){
	
	printf("Name : Rajan \n");
	printf("Branch: Btech [CS] \n");
	
}
