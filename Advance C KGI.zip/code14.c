#include <stdio.h>

int main(){
	
	int a = 34;
	int b = 12;
	
	
	
	printf("%d  %d", a, b);
	
	return 0;
}
