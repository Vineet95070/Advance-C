#include <stdio.h>

int main()
{
	
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	printf("Rajan \n");
	
	return 0;
}
