#include <stdio.h>

//Take 4 student roll and age from user and print them using matrix.

int main(){
	
	int arr[3][3] = {{1,2,3}, {4,5,6}, {7,8,9}};
	
	printf("%d \n", arr[2][1]);
	
	return 0;
}
