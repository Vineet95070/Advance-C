#include <stdio.h>

int main(){
	
	int y = 14;		//automatic storage type
	
	auto int x = 12;	//automatic storage type
	
	printf("%d \n", y);
	
	printf("%d \n", x);
	
	return 0;
}
