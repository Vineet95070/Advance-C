#include <stdio.h>

int main(){
	
	int arr[5] = {23, 54, 78, 23, 87};
	
	int i=0;
	do{
		
		printf("%d ", arr[i]);
		
		i++;
		
	}while(i != 5);
	
	return 0;
}
