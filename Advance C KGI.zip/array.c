#include <stdio.h>

int main(){
	
	int arr[5];
	
	arr[0] = 23;
	arr[1] = 24;
	arr[2] = 25;
	arr[3] = 26;
	arr[4] = 27;
	
	printf("%d ", arr[0]);
	printf("%d ", arr[1]);
	printf("%d ", arr[2]);
	printf("%d ", arr[3]);
	printf("%d ", arr[4]);
	
	return 0;
}
