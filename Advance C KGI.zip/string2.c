#include <stdio.h>
#include <string.h>

int main(){
	
	char name[] = {"Shiva Ji"};
	
	
	printf("%d  \n", sizeof(name) );
	
//	int i=0;
//	while ( i <= strlen(name) ){
//		
//		printf("%c", name[i]);
//		
//		i++;
//	}
	
//	int i=0;
//	while ( name[i] != '\0'){
//		
//		printf("%c", name[i]);
//		
//		i++;
//	}
	
	
//	printf("%s \n", name);
//	
//	printf("%d  \n", strlen(name) );
//	
//	printf("%c  \n", name[0] );
	
	return 0;
}
