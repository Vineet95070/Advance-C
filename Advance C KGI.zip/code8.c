#include <stdio.h>

int main(){
	
	
	int var = 032;
	
	printf("%d \n", var);
	
//	%o use for octal
	printf("%o \n", var);
	
//	%p use for hexadecemal
	printf("%p \n", &var);
	
	
	return 0;
}
