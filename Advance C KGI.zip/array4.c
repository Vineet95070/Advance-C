#include <stdio.h>

int main(){
	
	
	int arr[5] = {23, 54, 78, 23, 87};
	
	int i;
	for(i=0; i<5; i++){
		
		printf("%d ", arr[i]);
	}
	
	return 0;
}
